using VendorAudit.Core.Entities;
using VendorAudit.Infrastructure.AI;
using Xunit;

namespace VendorAudit.Tests;

public class RiskScoringServiceTests
{
    private readonly RiskScoringService _sut = new();

    private static Vendor VendorWith(params AuditFinding[] findings)
    {
        var vendor = new Vendor { Id = 1, Name = "Test Vendor", Category = "Test" };
        foreach (var f in findings) { f.VendorId = 1; vendor.Findings.Add(f); }
        return vendor;
    }

    [Fact]
    public void NoFindings_IsLowRisk()
    {
        var vendor = VendorWith();
        var result = _sut.Score(vendor);
        Assert.Equal(RiskRating.Low, result.Rating);
        Assert.Empty(result.ContributingFindingIds);
    }

    [Fact]
    public void OpenHighSeverityFinding_DrivesHighRisk()
    {
        var vendor = VendorWith(
            new AuditFinding { Id = 1, Title = "No MFA", Severity = Severity.High, Status = FindingStatus.Open, Date = new DateOnly(2025, 1, 1) },
            new AuditFinding { Id = 2, Title = "Old report", Severity = Severity.Low, Status = FindingStatus.Closed, Date = new DateOnly(2025, 1, 1) });

        var result = _sut.Score(vendor);

        Assert.Equal(RiskRating.High, result.Rating);
        Assert.Contains(1, result.ContributingFindingIds);
        Assert.DoesNotContain(2, result.ContributingFindingIds); // closed findings never contribute
        Assert.Contains("No MFA", result.Reasoning);
    }

    [Fact]
    public void ClosedHighSeverityFinding_DoesNotDriveHighRisk()
    {
        var vendor = VendorWith(
            new AuditFinding { Id = 1, Title = "Old High, fixed", Severity = Severity.High, Status = FindingStatus.Closed, Date = new DateOnly(2025, 1, 1) });

        var result = _sut.Score(vendor);

        Assert.Equal(RiskRating.Low, result.Rating);
    }

    [Fact]
    public void SingleOpenMediumFinding_IsMediumRisk()
    {
        var vendor = VendorWith(
            new AuditFinding { Id = 1, Title = "Undocumented policy", Severity = Severity.Medium, Status = FindingStatus.Open, Date = new DateOnly(2025, 1, 1) });

        var result = _sut.Score(vendor);

        Assert.Equal(RiskRating.Medium, result.Rating);
        Assert.Contains(1, result.ContributingFindingIds);
    }

    [Fact]
    public void TwoOrMoreOpenLowFindings_CompoundToMediumRisk()
    {
        var vendor = VendorWith(
            new AuditFinding { Id = 1, Title = "Low A", Severity = Severity.Low, Status = FindingStatus.Open, Date = new DateOnly(2025, 1, 1) },
            new AuditFinding { Id = 2, Title = "Low B", Severity = Severity.Low, Status = FindingStatus.InRemediation, Date = new DateOnly(2025, 1, 1) });

        var result = _sut.Score(vendor);

        Assert.Equal(RiskRating.Medium, result.Rating);
    }

    [Fact]
    public void SingleOpenLowFinding_IsLowRisk()
    {
        var vendor = VendorWith(
            new AuditFinding { Id = 1, Title = "Minor log gap", Severity = Severity.Low, Status = FindingStatus.Open, Date = new DateOnly(2025, 1, 1) });

        var result = _sut.Score(vendor);

        Assert.Equal(RiskRating.Low, result.Rating);
        Assert.Single(result.ContributingFindingIds);
    }
}
