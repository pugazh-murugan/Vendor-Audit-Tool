using VendorAudit.Core.Entities;
using VendorAudit.Infrastructure.AI;
using Xunit;

namespace VendorAudit.Tests;

public class StubAiAssistantTests
{
    private readonly RiskScoringService _riskScoring = new();

    [Fact]
    public async Task Summary_AgreesWithRiskScoringService()
    {
        var vendor = new Vendor { Id = 1, Name = "Acme Vendor", Category = "Cloud" };
        vendor.Findings.Add(new AuditFinding
        {
            Id = 1, VendorId = 1, Title = "No MFA enforced",
            Severity = Severity.High, Status = FindingStatus.Open, Date = new DateOnly(2025, 1, 1)
        });

        var sut = new StubAiAssistant(_riskScoring);
        var expected = _riskScoring.Score(vendor);

        var result = await sut.SummarizeVendorAsync(vendor);

        Assert.Equal(expected.Rating, result.SuggestedRating);
        Assert.Contains("Acme Vendor", result.Summary);
        Assert.Single(result.KeyFindings);
        Assert.Contains("No MFA enforced", result.KeyFindings[0]);
    }

    [Fact]
    public async Task Summary_ForVendorWithNoOpenFindings_MentionsAllClosed()
    {
        var vendor = new Vendor { Id = 2, Name = "Quiet Vendor", Category = "Facilities" };
        vendor.Findings.Add(new AuditFinding
        {
            Id = 2, VendorId = 2, Title = "Old issue, resolved",
            Severity = Severity.Medium, Status = FindingStatus.Closed, Date = new DateOnly(2024, 1, 1)
        });

        var sut = new StubAiAssistant(_riskScoring);
        var result = await sut.SummarizeVendorAsync(vendor);

        Assert.Equal(RiskRating.Low, result.SuggestedRating);
        Assert.Contains("closed", result.Summary, StringComparison.OrdinalIgnoreCase);
    }
}
