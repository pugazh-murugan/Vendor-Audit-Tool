using Microsoft.AspNetCore.Mvc;
using VendorAudit.Api.DTOs;
using VendorAudit.Core.Interfaces;

namespace VendorAudit.Api.Controllers;

[ApiController]
[Route("api/vendors/{vendorId:int}/ai-summary")]
public class AiAssistController : ControllerBase
{
    private readonly IVendorRepository _vendors;
    private readonly IAiAssistant _aiAssistant;

    public AiAssistController(IVendorRepository vendors, IAiAssistant aiAssistant)
    {
        _vendors = vendors;
        _aiAssistant = aiAssistant;
    }

    // POST /api/vendors/5/ai-summary
    [HttpPost]
    public async Task<ActionResult<AiSummaryDto>> Generate(int vendorId, CancellationToken ct)
    {
        var vendor = await _vendors.GetWithFindingsAsync(vendorId);
        if (vendor is null) return NotFound(new { error = $"Vendor {vendorId} not found." });

        if (vendor.Findings.Count == 0)
            return Ok(new AiSummaryDto(vendor.Id, vendor.Name, "No findings recorded for this vendor yet.", "Low", "No findings to assess.", Array.Empty<string>()));

        var summary = await _aiAssistant.SummarizeVendorAsync(vendor, ct);
        return Ok(summary.ToDto(vendor.Id, vendor.Name));
    }
}
