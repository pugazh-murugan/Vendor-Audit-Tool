using Microsoft.AspNetCore.Mvc;
using VendorAudit.Api.DTOs;
using VendorAudit.Core.Entities;
using VendorAudit.Core.Interfaces;

namespace VendorAudit.Api.Controllers;

[ApiController]
[Route("api/vendors/{vendorId:int}/findings")]
public class FindingsController : ControllerBase
{
    private readonly IFindingRepository _findings;
    private readonly IVendorRepository _vendors;

    public FindingsController(IFindingRepository findings, IVendorRepository vendors)
    {
        _findings = findings;
        _vendors = vendors;
    }

    // GET /api/vendors/5/findings
    [HttpGet]
    public async Task<ActionResult<List<FindingDto>>> GetForVendor(int vendorId)
    {
        var vendor = await _vendors.GetByIdAsync(vendorId);
        if (vendor is null) return NotFound(new { error = $"Vendor {vendorId} not found." });

        var findings = await _findings.GetByVendorIdAsync(vendorId);
        return Ok(findings.Select(f => f.ToDto()).ToList());
    }

    // POST /api/vendors/5/findings
    [HttpPost]
    public async Task<ActionResult<FindingDto>> Create(int vendorId, [FromBody] CreateFindingDto dto)
    {
        var vendor = await _vendors.GetByIdAsync(vendorId);
        if (vendor is null) return NotFound(new { error = $"Vendor {vendorId} not found." });

        if (string.IsNullOrWhiteSpace(dto.Title))
            return BadRequest(new { error = "Title is required." });

        var finding = new AuditFinding
        {
            VendorId = vendorId,
            Title = dto.Title,
            Notes = dto.Notes,
            Severity = dto.Severity,
            Status = dto.Status,
            Date = dto.Date
        };

        var created = await _findings.AddAsync(finding);
        return CreatedAtAction(nameof(GetForVendor), new { vendorId }, created.ToDto());
    }
}
