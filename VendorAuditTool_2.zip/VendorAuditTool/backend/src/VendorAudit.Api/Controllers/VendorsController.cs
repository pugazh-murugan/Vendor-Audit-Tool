using Microsoft.AspNetCore.Mvc;
using VendorAudit.Api.DTOs;
using VendorAudit.Core.Entities;
using VendorAudit.Core.Interfaces;

namespace VendorAudit.Api.Controllers;

[ApiController]
[Route("api/vendors")]
public class VendorsController : ControllerBase
{
    private readonly IVendorRepository _vendors;
    private readonly IRiskScoringService _riskScoring;

    public VendorsController(IVendorRepository vendors, IRiskScoringService riskScoring)
    {
        _vendors = vendors;
        _riskScoring = riskScoring;
    }

    // GET /api/vendors
    [HttpGet]
    public async Task<ActionResult<List<VendorListItemDto>>> GetAll()
    {
        var vendors = await _vendors.GetAllAsync();
        var ratings = vendors.ToDictionary(v => v.Id, v => _riskScoring.Score(v).Rating);
        return Ok(vendors.Select(v => v.ToListItem(ratings)).ToList());
    }

    // GET /api/vendors/5
    [HttpGet("{id:int}")]
    public async Task<ActionResult<VendorDetailDto>> GetById(int id)
    {
        var vendor = await _vendors.GetWithFindingsAsync(id);
        if (vendor is null) return NotFound(new { error = $"Vendor {id} not found." });
        return Ok(vendor.ToDetail());
    }

    // GET /api/vendors/5/risk
    [HttpGet("{id:int}/risk")]
    public async Task<ActionResult> GetRisk(int id)
    {
        var vendor = await _vendors.GetWithFindingsAsync(id);
        if (vendor is null) return NotFound(new { error = $"Vendor {id} not found." });
        var assessment = _riskScoring.Score(vendor);
        return Ok(new
        {
            vendorId = id,
            rating = assessment.Rating.ToString(),
            reasoning = assessment.Reasoning,
            contributingFindingIds = assessment.ContributingFindingIds
        });
    }
}
