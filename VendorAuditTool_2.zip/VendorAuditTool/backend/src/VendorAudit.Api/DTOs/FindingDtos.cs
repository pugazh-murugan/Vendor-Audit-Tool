using VendorAudit.Core.Entities;

namespace VendorAudit.Api.DTOs;

public record FindingDto(int Id, int VendorId, string Title, string Notes, string Severity, string Status, DateOnly Date);

public record CreateFindingDto(string Title, string Notes, Severity Severity, FindingStatus Status, DateOnly Date);

public static class FindingMappings
{
    public static FindingDto ToDto(this AuditFinding f) =>
        new(f.Id, f.VendorId, f.Title, f.Notes, f.Severity.ToString(), f.Status.ToString(), f.Date);
}
