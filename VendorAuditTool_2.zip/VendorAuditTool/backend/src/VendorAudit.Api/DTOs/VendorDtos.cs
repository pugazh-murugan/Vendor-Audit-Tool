using VendorAudit.Core.Entities;

namespace VendorAudit.Api.DTOs;

public record VendorListItemDto(int Id, string Name, string Category, string ContactEmail, int OpenFindingCount, string Rating);

public record VendorDetailDto(
    int Id,
    string Name,
    string Category,
    string ContactEmail,
    DateOnly OnboardedOn,
    List<FindingDto> Findings);

public static class VendorMappings
{
    public static VendorListItemDto ToListItem(this Vendor v, IReadOnlyDictionary<int, RiskRating> ratings)
    {
        var openCount = v.Findings.Count(f => f.Status != FindingStatus.Closed);
        var rating = ratings.TryGetValue(v.Id, out var r) ? r.ToString() : "Unknown";
        return new VendorListItemDto(v.Id, v.Name, v.Category, v.ContactEmail, openCount, rating);
    }

    public static VendorDetailDto ToDetail(this Vendor v) => new(
        v.Id, v.Name, v.Category, v.ContactEmail, v.OnboardedOn,
        v.Findings.OrderByDescending(f => f.Date).Select(f => f.ToDto()).ToList());
}
