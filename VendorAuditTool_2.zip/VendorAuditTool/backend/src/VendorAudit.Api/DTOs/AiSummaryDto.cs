using VendorAudit.Core.Interfaces;

namespace VendorAudit.Api.DTOs;

public record AiSummaryDto(int VendorId, string VendorName, string Summary, string SuggestedRating, string RatingReasoning, IReadOnlyList<string> KeyFindings);

public static class AiSummaryMappings
{
    public static AiSummaryDto ToDto(this AiVendorSummary s, int vendorId, string vendorName) =>
        new(vendorId, vendorName, s.Summary, s.SuggestedRating.ToString(), s.RatingReasoning, s.KeyFindings);
}
