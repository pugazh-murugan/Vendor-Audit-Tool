using Microsoft.EntityFrameworkCore;
using VendorAudit.Api.Middleware;
using VendorAudit.Core.Interfaces;
using VendorAudit.Infrastructure.AI;
using VendorAudit.Infrastructure.Data;
using VendorAudit.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

// --- Services -------------------------------------------------------------

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Vendor Audit API", Version = "v1" });
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// EF Core: SQLite by default for a zero-setup `dotnet run` (see README for why).
// Swap to UseSqlServer(builder.Configuration.GetConnectionString("SqlServer"))
// to point at SQL Server without touching any other code.
builder.Services.AddDbContext<AuditDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("Sqlite")));

builder.Services.AddScoped<IVendorRepository, VendorRepository>();
builder.Services.AddScoped<IFindingRepository, FindingRepository>();
builder.Services.AddScoped<IRiskScoringService, RiskScoringService>();

// AI assistant: stub by default (no external calls, deterministic, grounded in
// findings). Flip Ai:UseStub to false + register AzureOpenAiAssistant (and its
// Semantic Kernel dependencies) to use a real model - no controller changes needed.
var useStub = builder.Configuration.GetValue("Ai:UseStub", true);
if (useStub)
{
    builder.Services.AddScoped<IAiAssistant, StubAiAssistant>();
}
else
{
    builder.Services.AddScoped<IAiAssistant, AzureOpenAiAssistant>();
}

var app = builder.Build();

// --- Seed data (dev convenience) ------------------------------------------

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AuditDbContext>();
    db.Database.EnsureCreated();
    DbSeeder.Seed(db);
}

// --- Middleware pipeline ----------------------------------------------------

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowFrontend");
app.UseMiddleware<ApiKeyMiddleware>();
app.MapControllers();
app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

app.Run();

// Exposed for WebApplicationFactory-based integration tests.
public partial class Program { }
