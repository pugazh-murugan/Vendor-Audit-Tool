namespace VendorAudit.Api.Middleware;

/// <summary>
/// Minimal API-key gate to demonstrate an auth boundary for the take-home.
/// NOT production auth - see README "Auth, auditability, production hardening"
/// for what a real deployment would use (Azure AD / Entra ID + role-based
/// authorization, per the SmartDocs-style Azure stack).
/// </summary>
public class ApiKeyMiddleware
{
    private const string HeaderName = "X-Api-Key";
    private readonly RequestDelegate _next;
    private readonly IConfiguration _config;

    public ApiKeyMiddleware(RequestDelegate next, IConfiguration config)
    {
        _next = next;
        _config = config;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Let swagger and health checks through unauthenticated for demo convenience.
        var path = context.Request.Path.Value ?? "";
        if (path.StartsWith("/swagger") || path.StartsWith("/health"))
        {
            await _next(context);
            return;
        }

        var expected = _config["Auth:ApiKey"];
        if (!string.IsNullOrEmpty(expected))
        {
            if (!context.Request.Headers.TryGetValue(HeaderName, out var provided) ||
                provided != expected)
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await context.Response.WriteAsJsonAsync(new { error = "Missing or invalid X-Api-Key header." });
                return;
            }
        }

        await _next(context);
    }
}
