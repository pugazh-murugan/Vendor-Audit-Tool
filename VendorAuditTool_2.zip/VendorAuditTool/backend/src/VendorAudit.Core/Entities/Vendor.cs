namespace VendorAudit.Core.Entities;

public class Vendor
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty; // e.g. "Cloud Infrastructure", "Payroll"
    public string ContactEmail { get; set; } = string.Empty;
    public DateOnly OnboardedOn { get; set; }

    public ICollection<AuditFinding> Findings { get; set; } = new List<AuditFinding>();
}
