namespace VendorAudit.Core.Entities;

public enum Severity
{
    Low = 0,
    Medium = 1,
    High = 2
}

public enum FindingStatus
{
    Open = 0,
    InRemediation = 1,
    Closed = 2
}

public enum RiskRating
{
    Low = 0,
    Medium = 1,
    High = 2
}
