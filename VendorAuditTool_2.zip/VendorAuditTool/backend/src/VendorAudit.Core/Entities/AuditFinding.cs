namespace VendorAudit.Core.Entities;

public class AuditFinding
{
    public int Id { get; set; }
    public int VendorId { get; set; }
    public Vendor? Vendor { get; set; }

    public string Title { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public Severity Severity { get; set; }
    public FindingStatus Status { get; set; }
    public DateOnly Date { get; set; }
}
