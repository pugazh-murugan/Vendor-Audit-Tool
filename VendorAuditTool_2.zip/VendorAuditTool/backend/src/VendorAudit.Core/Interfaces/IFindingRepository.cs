using VendorAudit.Core.Entities;

namespace VendorAudit.Core.Interfaces;

public interface IFindingRepository
{
    Task<List<AuditFinding>> GetByVendorIdAsync(int vendorId);
    Task<AuditFinding?> GetByIdAsync(int id);
    Task<AuditFinding> AddAsync(AuditFinding finding);
}
