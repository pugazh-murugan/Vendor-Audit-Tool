using VendorAudit.Core.Entities;

namespace VendorAudit.Core.Interfaces;

public interface IVendorRepository
{
    Task<List<Vendor>> GetAllAsync();
    Task<Vendor?> GetByIdAsync(int id);
    Task<Vendor?> GetWithFindingsAsync(int id);
    Task<Vendor> AddAsync(Vendor vendor);
}
