using VendorAudit.Core.Entities;

namespace VendorAudit.Core.Interfaces;

public record AiVendorSummary(
    string Summary,
    RiskRating SuggestedRating,
    string RatingReasoning,
    IReadOnlyList<string> KeyFindings);

/// <summary>
/// Abstraction over "an AI that can look at a vendor's findings and produce a
/// narrative summary + risk rating suggestion". Swappable implementation:
/// StubAiAssistant (deterministic, no external calls) or a real LLM-backed
/// implementation (e.g. Azure OpenAI) behind the same contract.
/// </summary>
public interface IAiAssistant
{
    Task<AiVendorSummary> SummarizeVendorAsync(Vendor vendor, CancellationToken ct = default);
}
