using VendorAudit.Core.Entities;

namespace VendorAudit.Core.Interfaces;

/// <summary>
/// Result of a rule-based, explainable risk assessment for a vendor.
/// Every field is traceable back to the findings that produced it.
/// </summary>
public record RiskAssessment(
    RiskRating Rating,
    string Reasoning,
    IReadOnlyList<int> ContributingFindingIds);

public interface IRiskScoringService
{
    RiskAssessment Score(Vendor vendor);
}
