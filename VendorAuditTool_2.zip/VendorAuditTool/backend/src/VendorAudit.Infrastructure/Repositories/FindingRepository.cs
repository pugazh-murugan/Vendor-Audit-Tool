using Microsoft.EntityFrameworkCore;
using VendorAudit.Core.Entities;
using VendorAudit.Core.Interfaces;
using VendorAudit.Infrastructure.Data;

namespace VendorAudit.Infrastructure.Repositories;

public class FindingRepository : IFindingRepository
{
    private readonly AuditDbContext _db;
    public FindingRepository(AuditDbContext db) => _db = db;

    public async Task<List<AuditFinding>> GetByVendorIdAsync(int vendorId) =>
        await _db.Findings.AsNoTracking()
            .Where(f => f.VendorId == vendorId)
            .OrderByDescending(f => f.Date)
            .ToListAsync();

    public async Task<AuditFinding?> GetByIdAsync(int id) =>
        await _db.Findings.AsNoTracking().FirstOrDefaultAsync(f => f.Id == id);

    public async Task<AuditFinding> AddAsync(AuditFinding finding)
    {
        _db.Findings.Add(finding);
        await _db.SaveChangesAsync();
        return finding;
    }
}
