using Microsoft.EntityFrameworkCore;
using VendorAudit.Core.Entities;
using VendorAudit.Core.Interfaces;
using VendorAudit.Infrastructure.Data;

namespace VendorAudit.Infrastructure.Repositories;

public class VendorRepository : IVendorRepository
{
    private readonly AuditDbContext _db;
    public VendorRepository(AuditDbContext db) => _db = db;

    public async Task<List<Vendor>> GetAllAsync() =>
        await _db.Vendors.AsNoTracking()
            .Include(v => v.Findings)
            .OrderBy(v => v.Name)
            .ToListAsync();

    public async Task<Vendor?> GetByIdAsync(int id) =>
        await _db.Vendors.AsNoTracking().FirstOrDefaultAsync(v => v.Id == id);

    public async Task<Vendor?> GetWithFindingsAsync(int id) =>
        await _db.Vendors.AsNoTracking()
            .Include(v => v.Findings)
            .FirstOrDefaultAsync(v => v.Id == id);

    public async Task<Vendor> AddAsync(Vendor vendor)
    {
        _db.Vendors.Add(vendor);
        await _db.SaveChangesAsync();
        return vendor;
    }
}
