using VendorAudit.Core.Entities;
using VendorAudit.Core.Interfaces;

namespace VendorAudit.Infrastructure.AI;

/// <summary>
/// Deterministic, explainable rule-based risk scorer. This is the "ground truth"
/// rating; the AI assistant's suggestion is required to line up with this so the
/// AI output can never contradict the recorded audit data.
///
/// Rule (evaluated only against OPEN or IN-REMEDIATION findings, since closed
/// findings are already resolved and should not drive current risk):
///   - Any open High severity finding                         -> High
///   - Any open Medium finding, OR 2+ open Low findings        -> Medium
///   - Otherwise (only closed findings, or a single open Low)  -> Low
/// </summary>
public class RiskScoringService : IRiskScoringService
{
    public RiskAssessment Score(Vendor vendor)
    {
        var active = vendor.Findings
            .Where(f => f.Status != FindingStatus.Closed)
            .ToList();

        var openHigh = active.Where(f => f.Severity == Severity.High).ToList();
        var openMedium = active.Where(f => f.Severity == Severity.Medium).ToList();
        var openLow = active.Where(f => f.Severity == Severity.Low).ToList();

        if (openHigh.Count > 0)
        {
            var titles = string.Join("; ", openHigh.Select(f => f.Title));
            return new RiskAssessment(
                RiskRating.High,
                $"{openHigh.Count} unresolved High-severity finding(s): {titles}.",
                openHigh.Select(f => f.Id).ToList());
        }

        if (openMedium.Count > 0 || openLow.Count >= 2)
        {
            var contributing = openMedium.Concat(openLow).ToList();
            var reason = openMedium.Count > 0
                ? $"{openMedium.Count} unresolved Medium-severity finding(s): {string.Join("; ", openMedium.Select(f => f.Title))}."
                : $"{openLow.Count} unresolved Low-severity findings compound into a Medium risk.";
            return new RiskAssessment(RiskRating.Medium, reason, contributing.Select(f => f.Id).ToList());
        }

        if (active.Count == 0)
        {
            return new RiskAssessment(RiskRating.Low, "No open or in-remediation findings on record.", Array.Empty<int>());
        }

        return new RiskAssessment(
            RiskRating.Low,
            $"Only {active.Count} minor (Low-severity) open finding(s), no Medium/High exposure.",
            active.Select(f => f.Id).ToList());
    }
}
