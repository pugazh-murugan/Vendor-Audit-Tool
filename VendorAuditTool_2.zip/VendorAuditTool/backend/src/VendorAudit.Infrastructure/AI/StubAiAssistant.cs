using System.Text;
using VendorAudit.Core.Entities;
using VendorAudit.Core.Interfaces;

namespace VendorAudit.Infrastructure.AI;

/// <summary>
/// Deterministic "AI assist" implementation used when no LLM API key is configured.
/// It does NOT call any external model. Instead it composes a grounded narrative
/// summary directly from the vendor's own findings, and delegates the risk rating
/// to the same rule-based RiskScoringService used elsewhere, so the "AI" output can
/// never disagree with the auditable ground truth.
///
/// Swap this for a real LLM-backed IAiAssistant (see AzureOpenAiAssistant) by
/// changing one line of DI registration in Program.cs - the controller and the
/// rest of the app are unaffected.
/// </summary>
public class StubAiAssistant : IAiAssistant
{
    private readonly IRiskScoringService _riskScoring;
    public StubAiAssistant(IRiskScoringService riskScoring) => _riskScoring = riskScoring;

    public Task<AiVendorSummary> SummarizeVendorAsync(Vendor vendor, CancellationToken ct = default)
    {
        var assessment = _riskScoring.Score(vendor);
        var findings = vendor.Findings.OrderByDescending(f => f.Date).ToList();

        var sb = new StringBuilder();
        sb.Append($"{vendor.Name} ({vendor.Category}) has {findings.Count} recorded finding(s) ");
        sb.Append($"across the audit history. ");

        var open = findings.Where(f => f.Status != FindingStatus.Closed).ToList();
        if (open.Count == 0)
        {
            sb.Append("All findings are currently closed, indicating remediation is up to date. ");
        }
        else
        {
            var bySeverity = open.GroupBy(f => f.Severity)
                .OrderByDescending(g => g.Key)
                .Select(g => $"{g.Count()} {g.Key}");
            sb.Append($"{open.Count} finding(s) remain open or in remediation ({string.Join(", ", bySeverity)}). ");
        }

        sb.Append($"Suggested risk rating: {assessment.Rating}. Reasoning: {assessment.Reasoning}");

        var keyFindings = findings
            .Take(5)
            .Select(f => $"[{f.Severity}/{f.Status}] {f.Title} ({f.Date:yyyy-MM-dd})")
            .ToList();

        var result = new AiVendorSummary(
            Summary: sb.ToString(),
            SuggestedRating: assessment.Rating,
            RatingReasoning: assessment.Reasoning,
            KeyFindings: keyFindings);

        return Task.FromResult(result);
    }
}
