using VendorAudit.Core.Entities;
using VendorAudit.Core.Interfaces;

namespace VendorAudit.Infrastructure.AI;

/// <summary>
/// Sketch of the real implementation. Not wired up by default (no API key in this
/// environment) - included to show how the AI-assist boundary would be filled in
/// production, via Semantic Kernel + Azure OpenAI, without touching the controller
/// or the risk-scoring rule. The prompt is grounded by only ever including the
/// vendor's own recorded findings as context, and the model is instructed to pick
/// a rating consistent with RiskScoringService rather than invent its own scale.
/// </summary>
public class AzureOpenAiAssistant : IAiAssistant
{
    private readonly IRiskScoringService _riskScoring;
    // private readonly Kernel _kernel; // Semantic Kernel, injected via DI in production

    public AzureOpenAiAssistant(IRiskScoringService riskScoring /*, Kernel kernel */)
    {
        _riskScoring = riskScoring;
        // _kernel = kernel;
    }

    public async Task<AiVendorSummary> SummarizeVendorAsync(Vendor vendor, CancellationToken ct = default)
    {
        var groundTruth = _riskScoring.Score(vendor);

        // Example of what production wiring looks like:
        //
        // var findingsBlock = string.Join("\n", vendor.Findings.Select(f =>
        //     $"- [{f.Severity}/{f.Status}] {f.Title}: {f.Notes} ({f.Date:yyyy-MM-dd})"));
        //
        // var prompt = $"""
        //     You are assisting a vendor auditor. Summarize the findings below in 3-4
        //     sentences, in plain language, for a non-technical reviewer. Do not invent
        //     findings that are not listed. The rule-based risk rating has already been
        //     computed as {groundTruth.Rating} because: {groundTruth.Reasoning}
        //     Explain that reasoning in your own words; do not propose a different rating.
        //
        //     Findings for {vendor.Name}:
        //     {findingsBlock}
        //     """;
        //
        // var response = await _kernel.InvokePromptAsync(prompt, cancellationToken: ct);
        // var summaryText = response.ToString();

        await Task.CompletedTask;
        throw new NotImplementedException(
            "AzureOpenAiAssistant is a wiring sketch for production; configure Ai:UseStub=false " +
            "and supply Azure OpenAI credentials + Semantic Kernel setup to activate it.");
    }
}
