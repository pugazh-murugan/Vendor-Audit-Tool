using VendorAudit.Core.Entities;

namespace VendorAudit.Infrastructure.Data;

public static class DbSeeder
{
    public static void Seed(AuditDbContext db)
    {
        if (db.Vendors.Any()) return; // already seeded

        var vendors = new List<Vendor>
        {
            new()
            {
                Name = "Nimbus Cloud Storage Pvt Ltd",
                Category = "Cloud Infrastructure",
                ContactEmail = "compliance@nimbuscloud.example",
                OnboardedOn = new DateOnly(2022, 3, 14),
                Findings = new List<AuditFinding>
                {
                    new() { Title = "No MFA enforced on admin console", Severity = Severity.High, Status = FindingStatus.Open, Date = new DateOnly(2025, 11, 2),
                        Notes = "Admin portal allows password-only login. No conditional access policy configured." },
                    new() { Title = "Data retention policy undocumented", Severity = Severity.Medium, Status = FindingStatus.Open, Date = new DateOnly(2025, 11, 2),
                        Notes = "Vendor could not produce a written data retention/deletion policy on request." },
                    new() { Title = "SOC 2 report is 14 months old", Severity = Severity.Low, Status = FindingStatus.InRemediation, Date = new DateOnly(2025, 9, 20),
                        Notes = "Renewal report requested; vendor has committed to a Q1 delivery date." },
                }
            },
            new()
            {
                Name = "Aarav Payroll Services",
                Category = "Payroll / Finance",
                ContactEmail = "audit@aaravpayroll.example",
                OnboardedOn = new DateOnly(2021, 7, 1),
                Findings = new List<AuditFinding>
                {
                    new() { Title = "Encryption at rest not confirmed for salary data", Severity = Severity.High, Status = FindingStatus.Open, Date = new DateOnly(2025, 10, 18),
                        Notes = "Vendor's infra team did not confirm AES-256 at rest for the payroll database during the walkthrough." },
                    new() { Title = "Employee offboarding access revocation delayed", Severity = Severity.High, Status = FindingStatus.Open, Date = new DateOnly(2025, 10, 18),
                        Notes = "Sample of 3 offboarded vendor staff still had system access 10+ days after termination." },
                    new() { Title = "Change management log incomplete for one release", Severity = Severity.Medium, Status = FindingStatus.Closed, Date = new DateOnly(2025, 6, 5),
                        Notes = "Remediated; vendor now uses a ticket-linked deployment log." },
                }
            },
            new()
            {
                Name = "BlueLeaf Analytics",
                Category = "Data Analytics",
                ContactEmail = "trust@blueleafanalytics.example",
                OnboardedOn = new DateOnly(2023, 1, 9),
                Findings = new List<AuditFinding>
                {
                    new() { Title = "Test data uses masked production samples", Severity = Severity.Low, Status = FindingStatus.Closed, Date = new DateOnly(2025, 8, 1),
                        Notes = "Confirmed masking script covers all PII columns; sample verified by our team." },
                    new() { Title = "Sub-processor list not disclosed proactively", Severity = Severity.Medium, Status = FindingStatus.Open, Date = new DateOnly(2025, 11, 10),
                        Notes = "Vendor uses two downstream analytics sub-processors not listed in the DPA appendix." },
                }
            },
            new()
            {
                Name = "Chakra Facilities Management",
                Category = "Physical / Facilities",
                ContactEmail = "ops@chakrafacilities.example",
                OnboardedOn = new DateOnly(2020, 5, 22),
                Findings = new List<AuditFinding>
                {
                    new() { Title = "Visitor log retained only 30 days", Severity = Severity.Low, Status = FindingStatus.Open, Date = new DateOnly(2025, 10, 30),
                        Notes = "Internal policy calls for 90-day minimum retention of visitor logs at server room entrances." },
                }
            },
            new()
            {
                Name = "Orion Identity & SSO",
                Category = "Identity / Security",
                ContactEmail = "security@orionidentity.example",
                OnboardedOn = new DateOnly(2024, 2, 12),
                Findings = new List<AuditFinding>
                {
                    new() { Title = "Penetration test findings remediated on time", Severity = Severity.Low, Status = FindingStatus.Closed, Date = new DateOnly(2025, 7, 15),
                        Notes = "All 4 findings from the Q2 pentest were closed within SLA." },
                    new() { Title = "Break-glass account not monitored", Severity = Severity.Medium, Status = FindingStatus.Open, Date = new DateOnly(2025, 11, 5),
                        Notes = "Emergency-access account exists but sign-in alerts are not wired to the SOC." },
                    new() { Title = "Quarterly access review evidence missing for Q3", Severity = Severity.Medium, Status = FindingStatus.Open, Date = new DateOnly(2025, 11, 5),
                        Notes = "Vendor could not produce the Q3 access recertification sign-off." },
                }
            },
        };

        db.Vendors.AddRange(vendors);
        db.SaveChanges();
    }
}
