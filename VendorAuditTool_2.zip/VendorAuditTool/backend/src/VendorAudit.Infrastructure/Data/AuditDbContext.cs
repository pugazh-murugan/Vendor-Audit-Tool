using Microsoft.EntityFrameworkCore;
using VendorAudit.Core.Entities;

namespace VendorAudit.Infrastructure.Data;

public class AuditDbContext : DbContext
{
    public AuditDbContext(DbContextOptions<AuditDbContext> options) : base(options) { }

    public DbSet<Vendor> Vendors => Set<Vendor>();
    public DbSet<AuditFinding> Findings => Set<AuditFinding>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Vendor>(e =>
        {
            e.Property(v => v.Name).IsRequired().HasMaxLength(200);
            e.Property(v => v.Category).HasMaxLength(100);
            e.Property(v => v.ContactEmail).HasMaxLength(200);
        });

        modelBuilder.Entity<AuditFinding>(e =>
        {
            e.Property(f => f.Title).IsRequired().HasMaxLength(300);
            e.Property(f => f.Notes).HasMaxLength(2000);
            e.HasOne(f => f.Vendor)
             .WithMany(v => v.Findings)
             .HasForeignKey(f => f.VendorId)
             .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
