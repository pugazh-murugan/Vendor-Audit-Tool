export const environment = {
  production: true,
  apiBaseUrl: '/api-proxy',
  apiKey: 'local-dev-key-change-me',
};
