export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:5000',
  apiKey: 'local-dev-key-change-me',
};
