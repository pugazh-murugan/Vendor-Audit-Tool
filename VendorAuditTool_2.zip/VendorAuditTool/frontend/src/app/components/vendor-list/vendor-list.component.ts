import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { VendorService } from '../../services/vendor.service';
import { VendorListItem } from '../../models/vendor.model';

@Component({
  selector: 'app-vendor-list',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="card">
      <h2>Vendors</h2>
      <p class="muted" *ngIf="loading()">Loading vendors...</p>
      <p class="muted" *ngIf="error()">{{ error() }}</p>

      <div *ngFor="let v of vendors()" class="vendor-row card" (click)="openVendor(v.id)">
        <div>
          <strong>{{ v.name }}</strong>
          <div class="muted">{{ v.category }} &middot; {{ v.openFindingCount }} open finding(s)</div>
        </div>
        <span class="badge badge-{{ v.rating }}">{{ v.rating }}</span>
      </div>
    </div>
  `,
})
export class VendorListComponent implements OnInit {
  private vendorService = inject(VendorService);
  private router = inject(Router);

  vendors = signal<VendorListItem[]>([]);
  loading = signal(true);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.vendorService.getVendors().subscribe({
      next: (data) => {
        this.vendors.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Could not load vendors. Is the API running on http://localhost:5000?');
        this.loading.set(false);
      },
    });
  }

  openVendor(id: number): void {
    this.router.navigate(['/vendors', id]);
  }
}
