import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { VendorService } from '../../services/vendor.service';
import { AiSummary, VendorDetail } from '../../models/vendor.model';

@Component({
  selector: 'app-vendor-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <a routerLink="/" class="btn-link">&larr; Back to vendors</a>

    <div class="card" *ngIf="vendor() as v">
      <h2>{{ v.name }}</h2>
      <p class="muted">{{ v.category }} &middot; {{ v.contactEmail }} &middot; onboarded {{ v.onboardedOn }}</p>

      <h3>Findings ({{ v.findings.length }})</h3>
      <div *ngFor="let f of v.findings" class="finding" [ngClass]="f.severity">
        <strong>{{ f.title }}</strong>
        <span class="badge badge-{{ f.severity }}">{{ f.severity }}</span>
        <div class="muted">{{ f.status }} &middot; {{ f.date }}</div>
        <p>{{ f.notes }}</p>
      </div>
    </div>

    <div class="card">
      <h3>AI Assist</h3>
      <button class="btn" (click)="generateSummary()" [disabled]="generating()">
        {{ generating() ? 'Generating...' : 'Generate AI Summary & Risk Rating' }}
      </button>

      <div *ngIf="summary() as s" style="margin-top: 16px;">
        <span class="badge badge-{{ s.suggestedRating }}">{{ s.suggestedRating }} risk</span>
        <p>{{ s.summary }}</p>
        <p class="muted"><em>Reasoning:</em> {{ s.ratingReasoning }}</p>
        <h4>Key findings referenced</h4>
        <ul>
          <li *ngFor="let k of s.keyFindings">{{ k }}</li>
        </ul>
      </div>

      <p class="muted" *ngIf="summaryError()">{{ summaryError() }}</p>
    </div>
  `,
})
export class VendorDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private vendorService = inject(VendorService);

  vendor = signal<VendorDetail | null>(null);
  summary = signal<AiSummary | null>(null);
  generating = signal(false);
  summaryError = signal<string | null>(null);

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.vendorService.getVendor(id).subscribe((v) => this.vendor.set(v));
  }

  generateSummary(): void {
    const v = this.vendor();
    if (!v) return;

    this.generating.set(true);
    this.summaryError.set(null);
    this.vendorService.generateAiSummary(v.id).subscribe({
      next: (s) => {
        this.summary.set(s);
        this.generating.set(false);
      },
      error: () => {
        this.summaryError.set('Could not generate AI summary right now.');
        this.generating.set(false);
      },
    });
  }
}
