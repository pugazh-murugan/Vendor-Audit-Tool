export interface VendorListItem {
  id: number;
  name: string;
  category: string;
  contactEmail: string;
  openFindingCount: number;
  rating: 'Low' | 'Medium' | 'High' | 'Unknown';
}

export interface Finding {
  id: number;
  vendorId: number;
  title: string;
  notes: string;
  severity: 'Low' | 'Medium' | 'High';
  status: 'Open' | 'InRemediation' | 'Closed';
  date: string;
}

export interface VendorDetail {
  id: number;
  name: string;
  category: string;
  contactEmail: string;
  onboardedOn: string;
  findings: Finding[];
}

export interface AiSummary {
  vendorId: number;
  vendorName: string;
  summary: string;
  suggestedRating: 'Low' | 'Medium' | 'High';
  ratingReasoning: string;
  keyFindings: string[];
}
