import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AiSummary, VendorDetail, VendorListItem } from '../models/vendor.model';

@Injectable({ providedIn: 'root' })
export class VendorService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiBaseUrl}/api/vendors`;

  getVendors(): Observable<VendorListItem[]> {
    return this.http.get<VendorListItem[]>(this.baseUrl);
  }

  getVendor(id: number): Observable<VendorDetail> {
    return this.http.get<VendorDetail>(`${this.baseUrl}/${id}`);
  }

  generateAiSummary(id: number): Observable<AiSummary> {
    return this.http.post<AiSummary>(`${this.baseUrl}/${id}/ai-summary`, {});
  }
}
