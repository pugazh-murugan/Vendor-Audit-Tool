import { HttpInterceptorFn } from '@angular/common/http';
import { environment } from '../../environments/environment';

/**
 * Attaches the demo API key configured in appsettings.json (Auth:ApiKey).
 * In production this would be replaced by a bearer token from Azure AD / Entra ID.
 */
export const apiKeyInterceptor: HttpInterceptorFn = (req, next) => {
  const cloned = req.clone({
    setHeaders: { 'X-Api-Key': environment.apiKey },
  });
  return next(cloned);
};
