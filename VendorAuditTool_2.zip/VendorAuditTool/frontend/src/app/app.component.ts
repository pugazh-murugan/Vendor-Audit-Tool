import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <header class="app-header">
      <h1>Vendor Audit Management</h1>
      <p>AI-assisted vendor risk review</p>
    </header>
    <main class="page">
      <router-outlet></router-outlet>
    </main>
  `,
})
export class AppComponent {}
