import { Routes } from '@angular/router';
import { VendorListComponent } from './components/vendor-list/vendor-list.component';
import { VendorDetailComponent } from './components/vendor-detail/vendor-detail.component';

export const routes: Routes = [
  { path: '', component: VendorListComponent },
  { path: 'vendors/:id', component: VendorDetailComponent },
  { path: '**', redirectTo: '' },
];
