# Vendor Audit Management (AI-Assisted) — Pre-Interview Challenge

A vertical slice of a Vendor Audit Management tool: auditors can list vendors,
open a vendor to see its findings, and generate an AI-assisted summary with an
explainable Low/Medium/High risk rating grounded in that vendor's own findings.

Stack: **ASP.NET Core 8 Web API** (repository/service layers) + **Angular 19**
(standalone components, signals) + **SQLite via EF Core** (SQL Server-ready) +
a swappable **AI assistant abstraction** (deterministic stub by default, Azure
OpenAI/Semantic Kernel sketch included).

---

## 1. How to run it

### Backend (API)

```bash
cd backend
dotnet restore
dotnet run --project src/VendorAudit.Api
```

- API listens on `http://localhost:5000` (see `launchSettings.json` / adjust
  as needed) and serves Swagger UI at `/swagger` in Development.
- On first run it creates `vendoraudit.db` (SQLite) next to the API project
  and seeds 5 vendors with findings automatically — nothing else to set up.
- Every request except `/swagger` and `/health` requires header
  `X-Api-Key: local-dev-key-change-me` (see `appsettings.json` → `Auth:ApiKey`).

### Frontend (Angular)

```bash
cd frontend
npm install
npm start
```

- Serves on `http://localhost:4200` and calls the API at
  `http://localhost:5000` (see `src/environments/environment.ts`).
- The API key header is attached automatically by `apiKeyInterceptor`.

### Tests

```bash
cd backend
dotnet test
```

Covers `RiskScoringService` (the explainable rule engine) and `StubAiAssistant`
(verifying its output always agrees with the rule engine and stays grounded in
the vendor's actual findings).

### Docker (stretch goal)

```bash
docker compose up --build
```

Builds and runs the API in a container on `localhost:5000` with a persisted
SQLite volume. The Angular app is run with `npm start` locally against it
(a frontend Dockerfile/nginx stage was out of scope for the 2-hour box — noted
below under "what I'd add").

---

## 2. What I built

- **Data model**: `Vendor` (name, category, contact, onboarded date) has many
  `AuditFinding` (title, notes, severity, status, date). EF Core with a
  cascade delete on findings when a vendor is removed.
- **API**: `VendorsController` (list/detail/risk), `FindingsController`
  (list/create findings per vendor), `AiAssistController`
  (`POST /api/vendors/{id}/ai-summary`).
- **Repository/service boundary**: `IVendorRepository` / `IFindingRepository`
  sit between EF Core and the controllers; `IRiskScoringService` and
  `IAiAssistant` are separate interfaces so persistence, scoring, and AI
  assistance can all be swapped or unit-tested independently.
- **Explainable risk scoring** (`RiskScoringService`): a small, deterministic
  rule evaluated only against **open/in-remediation** findings (closed
  findings don't drive current risk):
  - any open **High** finding → **High**
  - any open **Medium** finding, or 2+ open **Low** findings → **Medium**
  - otherwise → **Low**

  The result carries the exact finding IDs and titles that produced it, so
  every rating is traceable back to recorded data — nothing is a black box.
- **AI assist** (`StubAiAssistant`): composes a narrative summary directly
  from the vendor's findings and **delegates the rating to
  `RiskScoringService`**, so the "AI" can never contradict the auditable
  ground truth. `AzureOpenAiAssistant` is included as a wiring sketch showing
  how a real Semantic Kernel + Azure OpenAI call would slot into the same
  interface — the prompt would still be told the rule-based rating and asked
  to explain it, not invent its own scale.
- **Frontend**: vendor list (name, category, open finding count, rating
  badge) → vendor detail (findings with severity/status/notes) → "Generate AI
  Summary" button that calls the assist endpoint and renders the summary,
  rating, reasoning, and the key findings it's grounded in. Built with
  standalone components and `signal()` for local state (no NgRx needed at
  this scale).
- **Tests**: xUnit tests on the risk rule (including the "closed findings
  don't count" edge case) and on the stub assistant's grounding/agreement
  with the rule engine.
- **Basic auth**: a demo `X-Api-Key` middleware gate (see §4) — not
  production auth, but establishes the boundary.

---

## 3. Key decisions & trade-offs

| Decision | Why | Trade-off |
|---|---|---|
| **SQLite instead of SQL Server** | Zero external setup — `dotnet run` just works, no local SQL Server instance or connection string wrangling needed for a 2-hour review. | The connection string for SQL Server is already in `appsettings.json` (`ConnectionStrings:SqlServer`) and the only change needed is swapping `UseSqlite(...)` → `UseSqlServer(...)` in `Program.cs`. Schema/queries are plain EF Core LINQ, portable either way. |
| **Rule-based risk scoring, not LLM-derived** | The brief asks for the rating to be "explainable and grounded." A deterministic rule is trivially explainable and testable; an LLM-derived rating would need the same guardrail anyway. | Less nuanced than a model reasoning over context (e.g. vendor criticality, finding age) — noted under "what I'd improve." |
| **AI assistant behind an interface, stubbed by default** | No LLM API key in this environment; the brief explicitly allows/expects this. Keeps the assist endpoint fully functional and deterministic for grading, while the architecture (DI-swappable `IAiAssistant`) is what's actually being evaluated. | The stub's "summary" is templated rather than free-form prose — intentional, since it guarantees grounding for a take-home review. `AzureOpenAiAssistant` shows the intended production shape. |
| **Repository pattern over a bare `DbContext` in controllers** | Keeps controllers thin, makes `RiskScoringService`/`StubAiAssistant` unit-testable without a database, and mirrors the boundary the challenge explicitly asks for. | One extra layer of indirection for a small app — worth it here for testability and to demonstrate the pattern. |
| **Angular standalone components + signals over NgModules** | Matches current Angular idioms and keeps the app small (3 components, no routing modules boilerplate). | N/A at this scale; would revisit state management (e.g. a signal store) if the findings list grew large or needed cross-component sharing. |

---

## 4. Auth, auditability, and production data protection

**What's here now (demo-scoped):**
- A single shared `X-Api-Key` header checked by `ApiKeyMiddleware`, gating
  every endpoint except `/swagger` and `/health`.

**What a real deployment would add** (consistent with an Azure-based stack):
- **AuthN/AuthZ**: Azure AD / Microsoft Entra ID with OAuth2/OIDC; the API
  validates JWT bearer tokens (`Microsoft.Identity.Web`), and roles/claims
  (e.g. `Auditor`, `AuditAdmin`) drive `[Authorize(Roles = ...)]` on
  controllers — write actions (creating findings) restricted to auditors,
  read-only or summary-only roles for other reviewers.
- **Auditability**: every finding create/update and every AI-summary
  generation would be written to an append-only audit log (who, when, what
  vendor, what the AI/rule produced) — separate from the operational tables so
  it can't be edited after the fact. Azure would back this with immutable
  Blob storage or a dedicated audit table with row-level write-once
  constraints.
- **Production data protection**: findings/notes are potentially sensitive —
  encryption at rest (SQL Server TDE / Azure SQL default), encryption in
  transit (HTTPS everywhere, already the default for Kestrel + Azure App
  Service), secrets (API keys, LLM keys, connection strings) in **Azure Key
  Vault** rather than `appsettings.json`, and field-level masking/redaction
  for anything PII-adjacent before it's ever sent to an LLM prompt.
- **Rate limiting**: ASP.NET Core's built-in `Microsoft.AspNetCore.RateLimiting`
  on the AI-assist endpoint specifically, since that's the one with a real
  (LLM) cost per call.

---

## 5. What I'd do with more time

- Wire up `AzureOpenAiAssistant` for real (Semantic Kernel + Azure OpenAI),
  with the prompt still constrained to explain — not override — the
  rule-based rating, plus response caching so re-opening a vendor doesn't
  re-spend a model call.
- Replace the shared API key with Entra ID auth end-to-end and add role-based
  UI gating in Angular (hide "Generate AI Summary" from read-only roles).
- Add an audit trail table/endpoint (who generated which AI summary, when)
  and surface it in the UI — directly relevant to an *audit* tool.
- Pagination/filtering on the vendor list and findings (by severity/status)
  once data volume grows past a handful of vendors.
- A frontend Dockerfile (nginx serving the Angular build) plus an Azure
  deployment: API → **Azure App Service** (or Container Apps) with **Azure
  SQL Database**, frontend → **Azure Static Web Apps**, secrets in **Key
  Vault**, CI/CD via GitHub Actions building both images/artifacts.
- More edge-case tests (e.g. a vendor exactly on the Medium/Low boundary,
  concurrent finding creation) and a couple of integration tests against
  `WebApplicationFactory` for the controllers, not just the service layer.

---

## 6. AI tooling note

This solution was built with an AI coding assistant (Claude) doing the initial
scaffolding of the layered architecture, seed data, and Angular components,
which I then reviewed line by line. What I verified by hand: the risk-scoring
rule against the seeded findings (traced each of the 5 vendors' expected
rating manually), the DI wiring in `Program.cs` (stub-vs-real `IAiAssistant`
swap), and that the `AiAssistController` response can't diverge from
`RiskScoringService`. With another 2 hours I'd add the integration tests and
wire the real Azure OpenAI path described above rather than leave it as a
sketch.
